'use strict'

class LastUpdated {
  constructor(id, tableName, lastUpdated) {
    this.id = id
    this.tableName = tableName
    this.lastUpdated = lastUpdated
  }
}

module.exports = {
  LastUpdated
}

'use strict'

const pino = require('pino')

module.exports = pino({ name: 'phishurl-fetcher' })
